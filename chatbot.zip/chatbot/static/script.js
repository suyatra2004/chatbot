function sendMessage() {
  const inputField = document.getElementById("input");
  let input = inputField.value.trim();
  if (!input) return;

  const mainDiv = document.getElementById("message-section");

  const welcome = document.querySelector(".welcome-message");
  if (welcome) welcome.remove();

  const userDiv = document.createElement("div");
  userDiv.classList.add("message", "user-message");
  userDiv.innerHTML = `
    <div class="message-header"><i class="fas fa-user"></i> You</div>
    <div class="message-content">${input}</div>`;
  mainDiv.appendChild(userDiv);

  showTypingIndicator();
  inputField.value = "";

  fetch("/chat", {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({ message: input })
  })
    .then(res => res.json())
    .then(data => {
      removeTypingIndicator();
      const botDiv = document.createElement("div");
      botDiv.classList.add("message", "bot-message");
      botDiv.innerHTML = `
        <div class="message-header"><i class="fas fa-robot"></i> AI ChatBot</div>
        <div class="message-content">${data.response}</div>`;
      mainDiv.appendChild(botDiv);
      mainDiv.scrollTop = mainDiv.scrollHeight;

      const synth = window.speechSynthesis;
      const utterance = new SpeechSynthesisUtterance(data.response);
      synth.speak(utterance);
    });
}

function showTypingIndicator() {
  const mainDiv = document.getElementById("message-section");
  const typingDiv = document.createElement("div");
  typingDiv.classList.add("typing-indicator");
  typingDiv.id = "typing-indicator";
  typingDiv.innerHTML = `<span></span><span></span><span></span>`;
  mainDiv.appendChild(typingDiv);
  mainDiv.scrollTop = mainDiv.scrollHeight;
}

function removeTypingIndicator() {
  const typingDiv = document.getElementById("typing-indicator");
  if (typingDiv) typingDiv.remove();
}

document.addEventListener("DOMContentLoaded", () => {
  document.getElementById("input").addEventListener("keydown", function (e) {
    if (e.key === "Enter") {
      sendMessage();
    }
  });
});
