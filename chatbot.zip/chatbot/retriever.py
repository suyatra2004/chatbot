import json
import difflib

# Load the KG once
with open("mosdac_knowledge_graph.json", "r", encoding="utf-8") as f:
    kg = json.load(f)

# Prepare searchable index
section_map = {entry['target']: entry['target'] for entry in kg if entry['relation'] == 'has_section'}
text_map = {entry['source']: entry['target'] for entry in kg if entry['relation'] == 'contains_text'}

def get_response(user_input: str) -> str:
    # Find the closest matching section
    possible_sections = list(section_map.keys())
    match = difflib.get_close_matches(user_input.lower(), possible_sections, n=1, cutoff=0.4)

    if match:
        section = match[0]
        content = text_map.get(section)
        if content:
            return f"Here's what I found for **{section}**:\n\n{content}"
        else:
            return f"Sorry, I found a section related to '{section}', but no details were available."
    else:
        return "Sorry, I couldn't find anything relevant in the MOSDAC knowledge graph."
